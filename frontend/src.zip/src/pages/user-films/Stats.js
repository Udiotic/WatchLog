import React from 'react';

const Stats = () =>{
    return(
        <div></div>
    )
}
export default Stats;