import React from 'react';
import './books.css';
import Navbar from '../components/Navbar'

function Books(){
    return(
        <div className='container'>
            <Navbar/>
        </div>
    )
}

export default Books;