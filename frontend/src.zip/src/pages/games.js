import React from 'react';
import './games.css';
import Navbar from '../components/Navbar'

function Games(){
    return(
        <div className='container'>
            <Navbar/>
        </div>
    )
}

export default Games;