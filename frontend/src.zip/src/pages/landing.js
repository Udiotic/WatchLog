import React from 'react';
import './landing.css';
import Navbar from '../components/Navbar'
function Landing() {
    return (
        <div className="container">
            <Navbar/>
            </div>
    );
}

export default Landing;
