import React from 'react';
import './music.css';
import Navbar from '../components/Navbar'

function Music(){
    return(
        <div className='container'>
            <Navbar/>
        </div>
    )
}

export default Music;